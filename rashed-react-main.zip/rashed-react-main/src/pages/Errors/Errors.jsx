import React from 'react'


export const Error404 = ()=>{
    return(
        <div>Errors404 Not Found</div>
    )
}

export const Error401 = ()=>{
    return(
        <div>Errors401 Unauthorized Access</div>
    )
}